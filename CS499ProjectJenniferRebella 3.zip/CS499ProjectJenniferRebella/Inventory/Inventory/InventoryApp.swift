//
//  InventoryApp.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/18/26.
//  Updated by Jennifer Rebella on 6/07/26

import SwiftUI
import Firebase

@main
struct InventoryApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate

    let persistenceController = PersistenceController.shared
    
    @StateObject var listViewModel: ListViewModel = ListViewModel()
  
    var body: some Scene {
        WindowGroup {
            
            NavigationView{
                //LoginView().environment(\.managedObjectContext, persistenceController.container.viewContext)
                AuthenticationView().environment(\.managedObjectContext, persistenceController.container.viewContext)
                SignInView().environment(\.managedObjectContext, persistenceController.container.viewContext)
                ListView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
                AddItemView().environment(\.managedObjectContext, persistenceController.container.viewContext)
            }.environmentObject(listViewModel).environmentObject(listViewModel)
        
        }
    }
}
class AppDelegate: NSObject, UIApplicationDelegate {
  func application(_ application: UIApplication,
                   didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
    FirebaseApp.configure()

    return true
  }
}

