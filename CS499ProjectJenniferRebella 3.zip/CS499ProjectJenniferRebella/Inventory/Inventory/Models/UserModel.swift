//
//  UserModel.swift
//  Inventory
//
//  Created by Jennifer Rebella on 6/4/26.
//

import Foundation

//struct UserModel: Identifiable, Codable{
//    let id: String
//    @Published var username: String = ""
//    @Published var password: String = ""
//    let firstName: String
//    let lastName: String
//    init(id: String = UUID().uuidString,username: String, password: String, firstName: String, lastName:String) {
//        self.id = id
//        self.username = username
//        self.password = password
//        self.firstName = firstName
//        self.lastName = lastName
//    }
//    func newUser()-> UserModel{
//        return UserModel(id: id, username: username, password: password, firstName: firstName, lastName: lastName)
//    }
//    
//}
