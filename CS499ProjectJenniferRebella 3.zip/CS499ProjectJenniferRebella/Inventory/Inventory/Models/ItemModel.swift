//
//  ItemModel.swift
//  Inventory
//
//  Created by Chloe Watson on 5/30/26.
//

import Foundation

struct ItemModel: Identifiable, Codable{
    let id: String
    let name: String
    let qty: Int
    let desc: String
    
    init(id: String = UUID().uuidString, name: String, qty: Int, desc: String) {
        self.id = id
        self.name = name
        self.qty = qty
        self.desc = desc
    }
    func updateItem(newQty: Int)-> ItemModel{
        
        return ItemModel(id: id, name: name, qty: newQty, desc: desc)
    }

}

