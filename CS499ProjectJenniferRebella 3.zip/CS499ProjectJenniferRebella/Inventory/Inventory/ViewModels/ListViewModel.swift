//
//  ListViewModel.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/30/26.
//  Updated by Jennifer Rebella on 6/01/26

import Foundation

class ListViewModel: ObservableObject{
    @Published var items: [ItemModel] = []
    { didSet{
        saveItems()
    }}
    @Published var itemsKey: String = "store_1"
    @Published var searchText: String = ""
    
    //private let dataService = ItemModel()
    init(){
        getItems()
    }
    func getItems(){
        //starting data for testing list
//        let newItems = [ItemModel(id: "S001",
//                                  name: "Diet Coke 2 Liter",
//                                  qty: 63,
//                                  desc: "Two liter of diet pop by Coco-Cola"),
//                     ItemModel(id: "S002",
//                           name: "Coca-Cola 2 Liter",
//                           qty: 94,
//                           desc: "Two liter of pop by Coco-Cola"),
//                     ItemModel(id: "S003",
//                           name: "Dr. Pepper 2 Liter",
//                           qty: 320,
//                           desc: "Two liter of pop by Keurig Dr. Pepper"),
//                     ItemModel(id: "S004",
//                           name: "Diet Dr. Pepper 2 Liter",
//                           qty: 273,
//                           desc: "Two liter of diet pop by Keurig Dr. Pepper")]
        //items.append(contentsOf: newItems)
        //switches data from JSON to list
        guard
            let data = UserDefaults.standard.data(forKey: itemsKey),
        let savedItems = try? JSONDecoder().decode([ItemModel].self, from: data)
        else{ return}
        self.items = savedItems
        
    }
    func deleteItem(indexSet: IndexSet) {
             items.remove(atOffsets: indexSet)
         }
    //appends a new item to the items list
    func addItems(NewId: String,
                   NewName: String,
                   newQtyStr: String,
                   NewDesc: String){
        var NewQtyInt:Int = 0
        let NewQty: Int? = Int(newQtyStr)
        if (NewQty != nil){
            NewQtyInt = NewQty!
        }
        let newItem = ItemModel(id: NewId, name: NewName, qty: NewQtyInt, desc: NewDesc)
        items.append(newItem)
      

    }
    //checks if qty is int other wise is 0 for updating item qty
    func editItem(item: ItemModel, qty: String){
        var NewQtyInt:Int = 0
        let NewQty: Int? = Int(qty)
        if (NewQty != nil){
            NewQtyInt = NewQty!
        }
        if let index = items.firstIndex(where: {$0.id == item.id}){
            items[index] = item.updateItem(newQty: NewQtyInt)
        }
        
    }
    // saves data to user defaults for now will implement next week when database is set up
    func saveItems(){
        if let encodedData = try? JSONEncoder().encode(items){
            //encodeds item to JSON
            UserDefaults.standard.set(encodedData, forKey: itemsKey)
        }
        
    }
    func updateSearch(){
//        Will implement search function next week when database is set up
//
//        $searchText
//            .combineLatest(<#T##other: Publisher##Publisher#>)
    }

    func logOut() throws{
        try AuthenticationManager.shared.signOut()
    }
}
