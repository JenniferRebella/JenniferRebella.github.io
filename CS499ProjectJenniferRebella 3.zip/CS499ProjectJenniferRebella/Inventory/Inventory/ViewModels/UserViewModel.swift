//
//  UserViewModel.swift
//  Inventory
//
//  Created by Jennifer Rebella on 6/4/26.
//  Updated by Jennifer Rebella on 6/7/26

import Foundation

//class UserViewModel: ObservableObject{
//    @Published var users: [UserModel] = []
//    { didSet{
//        saveUsers()
//    }}
//    @Published var userKey: String = "User_data"
//    
//    
//    init(){
//        getUsers()
//    }
//    func getUsers(){
//        
//        //switches data from JSON to list
//        guard
//            let data = UserDefaults.standard.data(forKey: userKey),
//            let savedUsers = try? JSONDecoder().decode([UserModel].self, from: data)
//        else{ return}
//        self.users = savedUsers
//        
//    }
//    
//    // saves data to user defaults for now will implement next week when database is set up
//    func saveUsers(){
//        if let encodedData = try? JSONEncoder().encode(users){
//            //encodeds item to JSON
//            UserDefaults.standard.set(encodedData, forKey: userKey)
//        }
//        
//    }
//    
//}
