//
//  AuthenticationManger.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/21/26.
//  Updated by Jennifer Rebella on 6/07/26
//

import Foundation
import FirebaseAuth

struct AuthDataResultModel{
    let uid: String
    let email: String?
    init(user: User){
        self.uid = user.uid
        self.email = user.email
    }
}
final class  AuthenticationManager{
 static let shared = AuthenticationManager()
    private init(){}
    
    func getAuthenticatedUser() throws -> AuthDataResultModel{
        guard let user = Auth.auth().currentUser else{
            throw URLError(.badServerResponse)
        }
        return AuthDataResultModel(user: user)
    }
    func createUser(email: String, password: String) async throws -> AuthDataResultModel{
        let authDataResult = try await Auth.auth().createUser(withEmail: email, password: password)
        return AuthDataResultModel(user: authDataResult.user)
    }
    func signOut() throws{
        try Auth.auth().signOut()
    }
}
