//
//  AuthenticationView.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/21/26.
//  Updated by Jennifer Rebella on 6/07/26


import SwiftUI

struct AuthenticationView: View {
    var body: some View {
        NavigationView{
            NavigationLink("Login with Email", destination: SignInView())
        }
    }
        }
    

struct AuthenticationView_Previews: PreviewProvider {
    static var previews: some View {
        AuthenticationView()
    }
}
