//
//  SignInView.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/21/26.
//  Updated by Jennifer Rebella on 6/07/26

import SwiftUI
final class SignInViewModel: ObservableObject{
    @Published var email = ""
    @Published var password = ""
    
    func signIn(){
        guard !email.isEmpty, !password.isEmpty else{
            print("No email or password.")
            return
        }
        Task{
            do{
                let returnedUserData = try await AuthenticationManager.shared.createUser(email: email, password: password)
                
                print("Success")
                print(returnedUserData)
            }catch{
                print("Error:\(error)")
            }
        }
    }
}
struct SignInView: View {
    @StateObject private var viewModel = SignInViewModel()
    var body: some View {
        VStack{
            TextField("UserName", text: $viewModel.email)
                .padding(.leading)
            
            SecureField("Password",text: $viewModel.password)
                .padding(.leading)
            
            Button("Sign In with Email") {
                viewModel.signIn()
                
            }
        }
    }
    }


struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
    }
}
