//
//  AddItemView.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/30/26.
//  Updated by Jennifer Rebella on 5/31/26

import SwiftUI

struct AddItemView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var listViewModel: ListViewModel
    @State var newId: String = ""
    @State var newName: String = ""
    @State var newDesc: String = ""
    @State var newQtyString: String = ""
    @State var alertTitle: String = ""
    @State var showAlert: Bool = false
    var body: some View {
        ScrollView{
            VStack {
                TextField("Enter ID", text: $newId)
                TextField("Enter Description", text: $newDesc)
                TextField("Enter Name", text: $newName)
                TextField("Enter Quantiry in whole numbers only", text: $newQtyString)
                Button(action: addButtonPressed, label: {Text("Add")})
            }
            
        }.navigationTitle("Add Item")
            .alert(isPresented: $showAlert, content: getAlert)
    }
    func addButtonPressed(){
        if fieldIsComplete()  {
            listViewModel.addItems(NewId: newId, NewName: newName, newQtyStr: newQtyString, NewDesc: newDesc)
            presentationMode.wrappedValue.dismiss()
        }
    }
    //changes blank alert to fill out fleid
    func fieldIsComplete()-> Bool{
        if (newName.count < 4){
            alertTitle = "Please have a name of more than 3 characters"
            showAlert.toggle()
            return false
        }
        return true
        
    }
    //sends alert
    func getAlert()-> Alert{
        return Alert(title: Text(alertTitle))
    }
}

struct AddItemView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            AddItemView()
        }.environmentObject(ListViewModel())
    }
}
