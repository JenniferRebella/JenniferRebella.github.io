//
//  LoginView.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/29/26.
//  Updated by Jennifer Rebella on 5/31/26

import SwiftUI
final class LoginViewModel: ObservableObject{
    @Published var username:String = ""
    @Published var password:String = ""
}
struct LoginView: View {
    
    @StateObject private var viewModel = LoginViewModel()
    var body: some View {
        
        ScrollView{
            VStack {
                
            }
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        
        NavigationView{
            //LoginView()
        }
    }
}
