//
//  SearchView.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/28/26.
//  Updated by Jennifer Rebella on 5/31/26
// testing out code for a different search function
//
//import SwiftUI
//
//struct SearchView: View {
//    @State var searchQuestion: String = ""
//    
//    var body: some View {
//        TextField("Enter Quantiry in whole numbers only", text: $searchQuestion)
//        
//        
//    }
//}
//
//struct SearchView_Previews: PreviewProvider {
//    static var previews: some View {
//        NavigationView{
//            SearchView()
//        }.environmentObject(ListViewModel())
//    }
//}
