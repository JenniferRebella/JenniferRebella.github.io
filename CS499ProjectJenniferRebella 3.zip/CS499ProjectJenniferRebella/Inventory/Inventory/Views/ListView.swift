//
//  ListView.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/21/26.
//  Updated by Jennifer Rebella on 6/01/26

import SwiftUI



struct ListView: View {
//
//    @FetchRequest(
//        sortDescriptors: [NSSortDescriptor(keyPath: \Items, ascending: true)],
//        animation: .default)
    @EnvironmentObject var listViewModel: ListViewModel
    @State var searchQuestion: String = ""

    @State private var showSignInView: Bool = false


//    var items: FetchedResults<Items>
    var body: some View {
        NavigationView {
            List {
                ForEach(listViewModel.items) { item in
                    ItemView(item: item)
                    //swipes to delete
                }.onDelete(perform: listViewModel.deleteItem);
                
            }
            
            .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                       NavigationLink("Add Item", destination: AddItemView())
                        
                      
                    }
            }
                 

        }.onAppear{
            let authuser = try? AuthenticationManager.shared.getAuthenticatedUser()
            self.showSignInView = authuser == nil
        }.searchable(text: $searchQuestion, prompt: "Search bar")
    }


}



struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            ListView()
        }.environmentObject(ListViewModel())
    }
}
