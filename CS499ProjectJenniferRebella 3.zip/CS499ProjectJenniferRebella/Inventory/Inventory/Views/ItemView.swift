//
//  ItemView.swift
//  Inventory
//
//  Created by Jennifer Rebella on 6/02/26.
//  Updated by Jennifer Rebella on 6/07/26

import SwiftUI

struct ItemView: View {
    @EnvironmentObject var listViewModel: ListViewModel
    @State var newQtyString:String = ""
    let item: ItemModel
    var body: some View {

    
        HStack{
            Text("ID: \(item.id) Name: \(item.name) Qty: \(item.qty) Desc: \(item.desc)")
            
       
            TextField("Enter Quantiry in whole numbers only", text: $newQtyString)
            Button(action: addButtonPressed, label: {Text("Update")})
            
        }
    }
    func addButtonPressed(){
        listViewModel.editItem(item: item, qty: newQtyString)
    }
}

struct ItemView_Previews: PreviewProvider {

    static var previews: some View {
        var newItem1 = ItemModel(id: "S001",
                                        name: "Diet Coke 2 Liter",
                                        qty: 63,
                                        desc: "Two liter of diet pop by Coco-Cola")
        var newItem2 = ItemModel(id: "S002",
                                 name: "Coca-Cola 2 Liter",
                                 qty: 94,
                                 desc: "Two liter of pop by Coco-Cola")
         var newItem3 =
                           ItemModel(id: "S003",
                                 name: "Dr. Pepper 2 Liter",
                                 qty: 320,
                                 desc: "Two liter of pop by Keurig Dr. Pepper")
        Group{
            ItemView(item: newItem1)
            ItemView(item: newItem2)
            ItemView(item: newItem3)
        }.previewLayout(.sizeThatFits)
    }
}
