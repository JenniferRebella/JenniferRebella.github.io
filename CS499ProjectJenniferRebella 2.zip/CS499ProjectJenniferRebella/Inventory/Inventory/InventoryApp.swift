//
//  InventoryApp.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/18/26.
//  Updated by Jennifer Rebella on 5/31/26

import SwiftUI

@main
struct InventoryApp: App {
    let persistenceController = PersistenceController.shared
    
    @StateObject var listViewModel: ListViewModel = ListViewModel()
    
    var body: some Scene {
        WindowGroup {
            
            NavigationView{
                LoginView().environment(\.managedObjectContext, persistenceController.container.viewContext)
                ListView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
                AddItemView().environment(\.managedObjectContext, persistenceController.container.viewContext)
            }.environmentObject(listViewModel)
        
        }
    }
}
