//
//  LoginView.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/29/26.
//  Updated by Jennifer Rebella on 5/31/26

import SwiftUI

struct LoginView: View {
    @State var username: String = ""
    @State var password: String = ""
    //struct User{
    //    @State var username: String = ""
    //    @State var password: String = ""
    //}
    //var body: some View {
    //    @State var user = User()
    //    TextField(
    //        "User name (email address)",
    //        text: $user.username)
    //
    //    SecureField(
    //        "Password",
    //        text: $user.password
    //    ) {
    //        //user(username: username, password: password)
    //    }
    //    //.border(Color(UIColor.separator))
    //    return user;
    //}
    //
    //
    //   // let user: UserLogin = UserLogin(username: <#T##String#>, password: <#T##String#>)
    //
    //

    var body: some View {
        
        ScrollView{
            VStack {
                
                TextField("UserName", text: $username)
                    .padding(.leading)
                
                SecureField("Password", text: $password)
                    .padding(.leading)
                
              NavigationLink("Login", destination: ListView())
            }.navigationTitle("Personal Inventory")
                .padding(.horizontal)
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            LoginView()
        }
    }
}
