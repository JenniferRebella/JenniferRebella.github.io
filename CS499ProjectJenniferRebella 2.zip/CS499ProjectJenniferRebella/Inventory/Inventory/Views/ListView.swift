//
//  ListView.swift
//  Inventory
//
//  Created by Jennifer Rebella on 5/21/26.
//  Updated by Jennifer Rebella on 5/31/26

import SwiftUI

struct ListView: View {
//
//    @FetchRequest(
//        sortDescriptors: [NSSortDescriptor(keyPath: \Items, ascending: true)],
//        animation: .default)
    @EnvironmentObject var listViewModel: ListViewModel
    @State var searchQuestion: String = ""

    

//    var items: FetchedResults<Items>
    var body: some View {
        
        NavigationView {
            List {
                ForEach(listViewModel.items) { item in
                    NavigationLink {
                        Text("ID: \(item.id) Name: \(item.name) Qty: \(item.qty) Desc: \(item.desc)")
                    } label: {
                        Text("ID: \(item.id), Name: \(item.name), Qty: \(item.qty)")
                   }
                        //swipes to delete
                }.onDelete(perform: listViewModel.deleteItem)
                
            }
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink("Update", destination: Text("Shurg") /*UpdateQtyView()*/)
                }
                
            }
            .toolbar {
                    ToolbarItem(placement: .navigationBarLeading) {
                       NavigationLink("Add Item", destination: AddItemView())
                        
                      
                    }
            }
                 

        }.searchable(text: $searchQuestion, prompt: "Search bar")
    }


}



struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView{
            ListView()
        }.environmentObject(ListViewModel())
    }
}
