//
//  UpdateQty.swift
//  Inventory
//
//  Created by Chloe Watson on 5/31/26.
//

import SwiftUI

struct UpdateQtyView: View {
//    @Environment(\.presentationMode) var presentationMode
//    @EnvironmentObject var listViewModel: ListViewModel
//    @State var newQtyString:String
  var body: some View {
//        
//        ScrollView{
//            VStack{
//                TextField("Enter Quantiry in whole numbers only", text: $newQtyString)
//                Button(action: addButtonPressed, label: {Text("Update")})
//                
//        }
//    }.navigationTitle("Update Qty")
//    }
//}
//func addButtonPressed(){
//        listViewModel.editItem(item: <#T##ItemModel#>, qty: "56"/*newQtyString*/)
//       // presentationMode.wrappedValue.dismiss()
//    
//}
//
//struct UpdateQtyView_Previews: PreviewProvider {
//    static var previews: some View {
//        NavigationView{
//            //UpdateQtyView()
//        }.environmentObject(listViewModel())
      Text("Hold")
  }
}
