//
//  SwiftUIViewMainMenu.swift
//  InventoryApp
//
//  Created by Jennifer Rebella on 5/23/26.
//

import SwiftUI

struct SwiftUIViewMainMenu: View {
    var body: some View {
        Text("Personal Inventory")
    }
}

struct SwiftUIViewMainMenu_Previews: PreviewProvider {
    static var previews: some View {
        SwiftUIViewMainMenu()
    }
}


