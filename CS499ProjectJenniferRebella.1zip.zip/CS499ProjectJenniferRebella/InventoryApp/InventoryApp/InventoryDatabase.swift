//
//  InventoryDatabase.swift
//  InventoryApp
//
//  Created by Jennifer Rebella on 5/22/26.
//
//  Updated on 5/22/26

import Foundation

import SwiftUI


struct ItemTable: View{
    var body: View{
        Table(itemArray){
            TableColumn("Item Name: ", value: \.name)
            TableColumn("Item Description: ", value: \.description)
            TableColumn("Item Number: ", value: \.itemNumber)
            TableColumn("Item QTY: ", value: \.qty)
        }
    }
}
