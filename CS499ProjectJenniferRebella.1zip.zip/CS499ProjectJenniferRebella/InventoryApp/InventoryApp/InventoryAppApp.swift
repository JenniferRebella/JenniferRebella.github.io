//
//  InventoryAppApp.swift
//  InventoryApp
//
//  Created by Jennifer Rebella on 5/18/26.
//
//  Updated on 5/22/26
//
/* This is an app for tracking the inventory of a company with the option to edit
   the items and switch between database that stores the items
*/
import Foundation
import SwiftUI

@main
struct InventoryAppApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            SwiftUIViewMainMenu()
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)

        }
    }
}
