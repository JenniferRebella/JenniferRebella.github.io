//
//  Login.swift
//  InventoryApp
//
//  Created by Jennifer Rebella
//  Updated on 5/22/26
//
/* This is an app for tracking the inventory of a company with the option to edit
   the items and switch between database that stores the items
*/
import Foundation
import SwiftUI

private var username: String = ""
private var password: String = ""
var body: some View {
    TextField(
        "User name (email address)",
        text: $username)
        .autocapitalization(.none)
        .disableAutocorrection(true)
        .border(Color(UIColor.separator))
    SecureField(
        "Password",
        text: $password
    ) {
        handleLogin(username: username, password: password)
    }
    .border(Color(UIColor.separator))
}

    
    //let user: UserLogin = UserLogin(username: <#T##String#>, password: <#T##String#>)
    

