//
//  InventoryAppInventory.swift
//  InventoryApp
//
//  Created by Jennifer Rebella on 5/22/26.
//
//  Updated on 5/22/26

import Foundation
import SwiftUI

struct item {
    let name: String
    let description: String
    var itemNumber: Int
    var qty: Int
    
}
var itemArray = [
    //item(name: <#T##String#>, description: <#T##String#>, itemNumber: <#T##Int#>, qty: <#T##Int#>)
]

