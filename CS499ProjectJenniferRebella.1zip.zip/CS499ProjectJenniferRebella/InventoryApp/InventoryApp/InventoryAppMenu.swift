//
//  InventoryAppMenu.swift
//  InventoryApp
//
//  Created by Jennifer Rebella on 5/22/26.
//
//  Updated on 5/22/26

import Foundation
import SwiftUI
